<?php
session_start();
function isLoggedIn() { return isset($_SESSION['user_id']); }
function currentUser() { return $_SESSION['user'] ?? null; }
function requireLogin() {
    if (!isLoggedIn()) { header('Location: index.php'); exit; }
}
function requireRole($role) {
    requireLogin();
    if ($_SESSION['user']['role'] !== $role) { header('Location: index.php'); exit; }
}
